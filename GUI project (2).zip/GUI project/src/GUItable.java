import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;
	
public class GUItable {
	

	public GUItable() {

		// Declaration of variables
				
		  // create JFrame and JTable and JPanel
        JFrame frame = new JFrame();
        JTable table = new JTable(); 
        JPanel panel = new JPanel();
        
      //  JLabel labelID = new JLabel();
        
        //setting up the frame 
       
       

		//JTextField userText = new JTextField(20);
		
        frame.setTitle("Netflix log in");
		frame.setSize(1000,700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		frame.setVisible(true);
		frame.setLayout(null);
		
		panel.setBounds(400,340,400,100);
		panel.setVisible(true);
		
		
		
		
		
	//	panel.add(userText);
		frame.add(panel);
		panel.add(table);
		frame.pack();
		
		
		frame.setVisible(true);
		panel.setLayout(null);
	
        
        // identifying model to the fields in the table 
        Object[] fields = {"MOVIE NAME"};
        DefaultTableModel model = new DefaultTableModel();
        model.setColumnIdentifiers(fields);
        
        //  the model to the table
        table.setModel(model);
       
        // create JTextFields
        JTextField MOVIE = new JTextField();
        JLabel movie = new JLabel("movie name");
        
        //identifying the text fields
        
        MOVIE.setBounds(200, 220, 200, 25);
        movie.setBounds(25,100,100,25);
  
        
        // create JButtons
        JButton Add = new JButton("Add");
        JButton Delete = new JButton("Delete");
        JButton Update = new JButton("Update");     
        
       
        
        Add.setBounds(20, 350, 100, 25);
        Update.setBounds(150, 350, 100, 25);
        Delete.setBounds(300, 350, 100, 25);
        
        // create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 0, 880, 200);
        
        frame.setLayout(null);
        
        frame.add(pane);
        
        // add JTextFields to the frame
        frame.add(MOVIE);
        frame.add(movie);
      
    
        // add JButtons to the jframe
        frame.add(Add);
        frame.add(Delete);
        frame.add(Update);
        
        // create an array of objects to set the row data
        Object[] row = new Object[1];
        
        // button add row
        Add.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
             
                row[0] = MOVIE.getText();
               
                // add row to the model
                model.addRow(row);
            }
        });
        
        // button remove row
        Delete.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
            
                // i = the index of the selected row
                int i = table.getSelectedRow();
                if(i >= 0){
                    // remove a row from jtable
                    model.removeRow(i);
                }
                else{
                    System.out.println("Delete Error");
                }
            }
        });
        
        // get selected row data From table to textfields 
        table.addMouseListener(new MouseAdapter(){
        
        @Override
        public void mouseClicked(MouseEvent e){
            
            // i = the index of the selected row
            int i = table.getSelectedRow();
            
            MOVIE.setText(model.getValueAt(i, 0).toString());
            
        }
        });
        
        // button update row
        Update.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
             
                // i = the index of the selected row
                int i = table.getSelectedRow();
                
                if(i >= 0) 
                {
                   model.setValueAt(MOVIE.getText(), i, 0);
                  
                }
                else{
                    System.out.println("Update Error");
                }
            }
        });
        
        
       
	}
	public static void main(String[] args) {
	new GUItable();
	}

}
