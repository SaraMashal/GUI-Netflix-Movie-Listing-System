import java.util.HashMap;

public class IDOfPasswords {
   static HashMap<String,String> LogInInfo = new HashMap<String,String>();
   
   IDOfPasswords(){
	   LogInInfo.put("sara", "susu");
	   LogInInfo.put("lubna", "labaneeeh");
	   LogInInfo.put("hiba", "smartieee");
	   LogInInfo.put("sasha", "sushiii");
	   LogInInfo.put("saba", "saaabaaa");
   }
   protected static HashMap getLogInInfo(){
	   return LogInInfo;
   }
}
