import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class logIn implements ActionListener {
	
	JFrame frame = new JFrame();
	
	JPanel panel = new JPanel();
	
	//text for username
    JLabel UserIdLabel = new JLabel("username");
	
	//text box for username
	JTextField userIdText = new JTextField();
	
	//text for password
	JLabel passwordLabel = new JLabel ("password");
	
	//text box for password
	
	JPasswordField passwordText = new JPasswordField();

	//login button
	JButton Loginbutton = new JButton("login");
	
	//reset button
	JButton Resetbutton = new JButton("reset");
	
	//login msg
	JLabel message = new JLabel();
	
	//background img
	ImageIcon img = new ImageIcon("netflix-library-photo-scaled.jpg");
	
	JLabel background;
		
	HashMap<String,String> lognininfo = new HashMap<String,String>();
	

	logIn(HashMap<String,String>loginInfoOrOriginal){
		
		lognininfo = loginInfoOrOriginal;
		
		frame.setTitle("Netflix log in");
		frame.setSize(1000,700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		frame.setVisible(true);
		frame.setLayout(null);
		
		panel.setBounds(400,340,400,100);
		panel.setVisible(true);
		
		background = new JLabel("",img, JLabel.CENTER);
		background.setBounds(0,0,1000,700);
		frame.add(background);
		
		
		UserIdLabel.setBounds(500,0,500,500);
		UserIdLabel.setForeground(Color.WHITE);
		UserIdLabel.setFont(new Font(null,Font.PLAIN,15));
		frame.add(UserIdLabel);
		
		userIdText.setBounds(600,240,150,25);
		frame.add(userIdText);
		
		passwordLabel.setBounds(500,0,600,600);
		passwordLabel.setForeground(Color.WHITE);
		passwordLabel.setFont(new Font(null,Font.BOLD,15));
		frame.add(passwordLabel);
		
		passwordText.setBounds(600,290,150,25);
		frame.add(passwordText);
		
		Loginbutton.setBounds(500,400 ,100,25);
		Loginbutton.setFocusable(false);
		frame.add(Loginbutton);
		Loginbutton.addActionListener( this);
		 
		Resetbutton.setBounds(700,400,100,25);
		Resetbutton.setFocusable(false);
		frame.add(Resetbutton);
		Resetbutton.addActionListener(this);
		
		message.setBounds(580,50,500,900);
		message.setFont(new Font(null,Font.ITALIC,25));
		frame.add(message);
		
		
		frame.add(background);
		
	}

	  public void actionPerformed(ActionEvent e) {
		  if(e.getSource()==Resetbutton) {
			  userIdText.setText("");
			  passwordText.setText("");
			  
		  }
		  
		  if(e.getSource()==Loginbutton) {
			  String userID = userIdText.getText();
			  String password = String.valueOf(passwordText.getPassword());
			  String username = String.valueOf(userIdText.getText());
			  
			  if(lognininfo.containsKey(userID)) {
				  if(lognininfo.get(userID).equals(password)) {
					  message.setForeground(Color.GREEN);
					  message.setText("login successful");
					  frame.dispose();
					   GUItable moviepage = new GUItable();
				  }
				  else if(!lognininfo.get(userID).equals(password )) {
					  message.setForeground(Color.RED);
					  message.setText("wrong password, please reset and try again");
				  }
				  
			  }
			  else {
				  message.setForeground(Color.RED);
				  message.setText("user not found, please reset and try again");
			  }
		  }
		  
	  }

	}
