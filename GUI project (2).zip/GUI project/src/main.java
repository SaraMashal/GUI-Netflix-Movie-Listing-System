
public class main {

	public static void main(String[] args) {
		IDOfPasswords obj = new IDOfPasswords();
		logIn obj2 = new logIn(IDOfPasswords.getLogInInfo());
		
		 

	}

}
